package net.codejava.servlet;

import gr.forth.ics.graph.Graph;
import gr.forth.ics.graph.Node;
import gr.forth.ics.graph.PrimaryGraph;
import gr.forth.ics.graph.algo.KCoreDecomposition;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Set;
import java.util.SortedMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


@WebServlet("/UploadServlet")
@MultipartConfig(fileSizeThreshold=1024*1024*2,	// 2MB 
				 maxFileSize=1024*1024*50,		// 10MB
				 maxRequestSize=1024*1024*50)	// 50MB
public class UploadServlet extends HttpServlet {

	/**
	 * Name of the directory where uploaded files will be saved, relative to
	 * the web application directory.
	 */
	private static final String SAVE_DIR = "uploadFiles";
	
	private HashMap<String,Node> node = new HashMap<String,Node>();	
	private HashMap<Node, String> node_key = new HashMap<Node, String>();	
	private Graph g = new PrimaryGraph(); 
	
	
	/**
	 * handles file upload
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// gets absolute path of the web application
		String appPath = request.getServletContext().getRealPath("");
		// constructs path of the directory to save uploaded file
		String savePath = appPath + File.separator + SAVE_DIR;
		
		String FilePath="";
		
		// creates the save directory if it does not exists
		File fileSaveDir = new File(savePath);
		if (!fileSaveDir.exists()) {
			fileSaveDir.mkdir();
		}
		
		for (Part part : request.getParts()) {
			String fileName = extractFileName(part);
			part.write(savePath + File.separator + fileName);
			FilePath = savePath + File.separator + fileName;
		}
		
		
		// At this stage the file should be in place.
		// Let's try to open it and read it. 
		
		
		// Because how files are handled between OS, once the content is loaded we remove any \r invisible carriage return character.
		//contents = contents.replace(/(\r)/gm,"");		
		
		//var tab = RegExp("\\t", "g"); // g option : Perform a global match (find all matches rather than stopping after the first match)
		//contents.replace(tab, ' ');
		
		// ^n Matches any string with n at the beginning of it
		//var comment = /^#/;

				
		  try(BufferedReader br = new BufferedReader(new FileReader(FilePath))) {
		        StringBuilder sb = new StringBuilder();
		        String line = br.readLine();
		        line.replaceAll("\\r\\n", "");	

		        while (line != null) {
		        	//System.out.println(line);
		           // sb.append(line);
		           // sb.append(System.lineSeparator());
		           	        	
		        	if(!line.matches("(^#)(.*)")){
			        		
			        		String[] nodes = line.split("\\t");
			            // System.out.println("node1: " + nodes[0] + ", node2: " + nodes[1] );
			            	
			  			  Node n = g.newNode(nodes[0]);
						  this.node.put( nodes[0] , n ); 
						  this.node_key.put(  n  ,  nodes[0]   );
						  
			  			  Node nn = g.newNode(nodes[1]);
						  this.node.put( nodes[1] , nn ); 
						  this.node_key.put(  nn  ,  nodes[1]   );
						  
				       // g.newEdge(    node.get(  nodes[0]   )		, node.get(  nodes[1]  )	);
						  g.newEdge(    n		, nn	);
		        	}
		            
		        	

		            
		            // read the next line
		            line = br.readLine();
		        }
		       // String everything = sb.toString();
		    }
		
		//System.out.println("Graph g: " + g);
		System.out.println("Graph g created.");
		System.out.println("Calculating the cores ...");
		KCoreDecomposition kcore =  KCoreDecomposition.execute(g);	
		System.out.println("Geting the composition of each core ...");
		SortedMap<Integer, Set<Node>>  k_core = kcore.getCores();		 
		System.out.println("Writing the json  ...");
		
		System.out.println( "Number of Cores: " + k_core.keySet().size());
		
		   for(Integer i : k_core.keySet()){
			  // Set<Node> setNodes = k_core.get(i);
			   System.out.println("kore" + i + "" );
			   
		   }
		
		
		//String strResult =  kcoreToJson(k_core);		   
		//System.out.println( strResult);
		
		
		
		  
/*			// The following LinkedList are buffers, used to retrieve the data elements that we are interested in.
		  LinkedList< String> temp1 = new LinkedList<String>();
		  LinkedList< String> temp2 = new LinkedList<String>();
	
		  // From the text loaded, we extract the vertices, their ids and names.
		  temp1 =  find(jsonText, "id");
		  temp2 =  find(jsonText, "name");
		  // Next we store them in the node HashMap data structure
		  for(int i=0; i < temp2.size(); i++){ 
			  Node n = g.newNode(temp2.get(i));
			  this.node.put( temp1.get(i) , n ); 
			  this.node_key.put(  n  ,  temp1.get(i)   );
		  }

		  // Similarly, for the edges of the graph, we store the source and destination in the graph g
		  temp1 =  find(jsonText, "source");
		  temp2 =  find(jsonText, "target");
		  for(int i=0;  i < temp1.size(); i++){
			  this.g.newEdge(    node.get(   temp1.get(i)   )		, node.get(   temp2.get(i)   )	);
		  }*/
		  
		  
		  
		  System.out.println("End of the printing to the screen: " );
		
		request.setAttribute("message", "Upload has been done successfully!");
		getServletContext().getRequestDispatcher("/message.jsp").forward(
				request, response);
	}
	
	
	/**
	 * 
	 * @param k_core
	 * @return
	 */
	public String kcoreToJson(SortedMap<Integer, Set<Node>>  k_core){
			 
		 StringBuilder str = new StringBuilder("{\"kcores\": { ");
			 
		   for(Integer i : k_core.keySet()){
			   Set<Node> setNodes = k_core.get(i);
			   str.append(" \"kcore" + i + "\":[ " );
		   		for(Node n : setNodes)
		   			str.append( "{\"data\":{\"id\":\"" + node_key.get(n) + "\",\"name\":\"" + n + "\"}},");
		   		
		   		str.replace(str.length() -1, str.length(), "],");   			
		   }
		   
		   str.replace(str.length() -1, str.length(), "");
		   str.append( "   }} ");
		   
		   return str.toString();
		 
	}
	

	/**
	 * Extracts file name from HTTP header content-disposition
	 */
	private String extractFileName(Part part) {
		String contentDisp = part.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length()-1);
			}
		}
		return "";
	}
}